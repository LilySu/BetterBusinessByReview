#config file containing credentials for RDS MySQL instance
db_username = "tally_ds"
db_password = "P@ssw0rd"
db_name = "postgres" 
db_endpoint = "database-spotifier.c5eevkz7wazj.us-east-2.rds.amazonaws.com"